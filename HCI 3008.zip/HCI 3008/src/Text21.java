import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Text21 {
	private String Time;
	private String ID;
	private String Site;
	private String Scheme;
	private String Mode;
	private String Event;
	private String Data;
		public String getTime() {
			return Time;
		}
		public void setTime(String time) {
			Time = time;
		}
		public Date getTimeValue() {
			
			DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   			Date date = null;
   			try {
				 date =dateFormat.parse(Time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
   			
			return date;
			
		}
		public String getID() {
			return ID;
		}
		public void setID(String iD) {
			ID = iD;
		}
		public String getSite() {
			return Site;
		}
		public void setSite(String site) {
			Site = site;
		}
		public String getScheme() {
			return Scheme;
		}
		public void setScheme(String scheme) {
			Scheme = scheme;
		}
		public String getData() {
			return Data;
		}
		public void setData(String data) {
			Data = data;
		}
		public String getMode() {
			return Mode;
		}
		public void setMode(String mode) {
			Mode = mode;
		}
		public String getEvent() {
			return Event;
		}
		public void setEvent(String event) {
			Event = event;
		}


	

}
