import java.io.*;
import java.util.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class readWriteCsv {

	private static File FileOutput;

	 private static String finalcsv="final.csv";
	 private static FileWriter fileWriter=null;
	 private static List<Text21> text21s = new ArrayList<Text21>();

	 /**
	  * subtracts 2 dates and returns
	  * the absolute value in seconds as int**/
	 public static int diffTime(Date d1, Date d2) {
			long sum = Math.abs(d2.getTime() - d1.getTime());
		return (int) (sum/1000);

	}

	 /**
	  * searches the text 21 array
	  * starts at i till data is
	  * success/failure**/
	 public static int search(int i) {
		 int success=i;
		 while (!text21s.get(success).getData().equals("success")&&success<text21s.size()) {
			 success++;
		 }
		 int failure=i;
		 while (!text21s.get(failure).getData().equals("failure")&&failure<text21s.size()) {
			 failure++;
		 }
		 if (success<failure) {
			// System.out.println(success);
			return success;
		 }
		 //System.out.println(failure);
		return failure;

	 }
	 public static void readCsv(String filePath,String aScheme) {
		  BufferedReader reader = null;
		  List<String> IdList= new ArrayList<String>();
		  String scheme=aScheme;




		  try {
		   String line = "";
		   reader = new BufferedReader(new FileReader(filePath));


		   while((line = reader.readLine()) != null) {
		    String[] fields = line.split(",");

		    if(fields.length > 0) {
		     Text21 text21 = new Text21();
		     text21.setTime(fields[0]);
		     text21.setID((String)fields[1]);
		     if (!IdList.contains(text21.getID())) {
				IdList.add(text21.getID());
		     }

		     text21.setSite((String)fields[2]);
		     text21.setScheme((String)fields[3]);
		     text21.setMode((String)fields[4]);
		     text21.setEvent((String)fields[5]);
		     text21.setData((String)fields[6]);

		     text21s.add(text21);
		    }
		   }



		   for (int i = 0; i < IdList.size(); i++) {
			   	int success=0,failure=0;
			   	int totalFailureTime=0;
			   	int totalSuccessTime=0;

			   	for (int j = 0; j < text21s.size(); j++) {
			   		if (text21s.get(j).getID().equals(IdList.get(i))&&text21s.get(j).getData().equals("success")) {
			   			success++;
					}else if (text21s.get(j).getID().equals(IdList.get(i))&&text21s.get(j).getData().equals("failure")) {
						failure++;
					}
				}
			   	int j=0;
			   	while (j<text21s.size()) {
			   		int k=0;
					if (text21s.get(j).getID().equals(IdList.get(i))&&text21s.get(j).getData().equals("start")) {
			   			 k=search(j);
			   			if (text21s.get(k).getData().equals("success")) {
				   			totalSuccessTime+= diffTime(text21s.get(j).getTimeValue(), text21s.get(k).getTimeValue());
						}else {
				   			totalFailureTime+= diffTime(text21s.get(j).getTimeValue(), text21s.get(k).getTimeValue());

						}
				   		j=k;
					}
					j++;
				}
	            int totalLogins=success+failure;
            System.out.println("Id: "+IdList.get(i) + ", Scheme: "+scheme+", Logins: " +
	            totalLogins+", Success: "+success+", Failure: "+failure+
	            ", AverageFailureTime: "+totalFailureTime/failure+"s"+", AverageSuccessTime: "+totalSuccessTime/success+"s");
//	  		   fileWriter.append("Id: "+IdList.get(i) + ", Scheme: "+scheme+", Logins: " + totalLogins+", Success: "+success+", Failure: "+failure);
//	  		   fileWriter.append("\n");

		   }


		  }
		  catch (Exception ex) {
		   ex.printStackTrace();
		  } finally {
		   try {
		    reader.close();
		    fileWriter.flush();
		   // fileWriter.close();
		   } catch (Exception e) {
		    e.printStackTrace();
		   }
		  }

		 }


		public static void main(String[] args) {

			  String filePath = "C:\\Users\\emmad\\Desktop\\WN2019\\HCI 3008\\text21.csv";
			  String filePath2 = "C:\\Users\\emmad\\Desktop\\WN2019\\HCI 3008\\imagept21.csv";
			  FileOutput= new File(finalcsv);
			  try {
				fileWriter = new FileWriter(finalcsv);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			  if (FileOutput.exists()) {
				  FileOutput.delete();
			  }
			  try {
				FileOutput.createNewFile();
			} catch (Exception e) {
				// TODO: handle exception

			}

			  readCsv(filePath,"Text21");
			  System.err.println("");
			  readCsv(filePath2,"Image21");

			 }

}
