import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JPasswordField;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class EnterPasswordGUI extends JFrame {

	private JPanel contentPane;
	private JButton P1_Button;
	private JButton P2_Button;
	private JButton P3_Button;
	private JButton P4_Button;
	private JButton P5_Button;
	private JButton P6_Button;
	private JButton P7_Button;
	private JButton P8_Button;	private JButton Done_Button;
	private String ptype;
	private JLabel counter1;
	private JLabel counter2;
	private JLabel counter3;
	private JLabel counter4;
	private JLabel counter5;
	private JLabel counter6;
	private JLabel counter7;
	private JLabel counter8;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public EnterPasswordGUI(String Ptype) {
		this.setPtype(Ptype);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 688, 477);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Password:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		  
		  counter7 = new JLabel("counter");
		  GridBagConstraints gbc_counter7 = new GridBagConstraints();
		  gbc_counter7.insets = new Insets(0, 0, 5, 5);
		  gbc_counter7.gridx = 12;
		  gbc_counter7.gridy = 1;
		  contentPane.add(counter7, gbc_counter7);
		 
		  P7_Button = new JButton("Click");
		  GridBagConstraints gbc_P7_Button = new GridBagConstraints();
		  gbc_P7_Button.insets = new Insets(0, 0, 5, 5);
		  gbc_P7_Button.gridx = 13;
		  gbc_P7_Button.gridy = 1;
		  contentPane.add(P7_Button, gbc_P7_Button);
		  P7_Button.setBackground(Color.BLACK);
		  P7_Button.setForeground(Color.white);
		 		 		 
		 		 		 counter1 = new JLabel("counter");
		 		 		 GridBagConstraints gbc_counter1 = new GridBagConstraints();
		 		 		 gbc_counter1.insets = new Insets(0, 0, 5, 5);
		 		 		 gbc_counter1.gridx = 14;
		 		 		 gbc_counter1.gridy = 1;
		 		 		 contentPane.add(counter1, gbc_counter1);
		 		 
		 		 		
		 		 		
		 		 		
		 		 		 P1_Button = new JButton("Click");
		 		 		 GridBagConstraints gbc_P1_Button = new GridBagConstraints();
		 		 		 gbc_P1_Button.insets = new Insets(0, 0, 5, 0);
		 		 		 gbc_P1_Button.gridx = 15;
		 		 		 gbc_P1_Button.gridy = 1;
		 		 		 contentPane.add(P1_Button, gbc_P1_Button);
		 		 		 P1_Button.setBackground(Color.blue);
		 		 		 P1_Button.setForeground(Color.white);
		 		 
		 		 counter8 = new JLabel("counter");
		 		 GridBagConstraints gbc_counter8 = new GridBagConstraints();
		 		 gbc_counter8.insets = new Insets(0, 0, 5, 5);
		 		 gbc_counter8.gridx = 12;
		 		 gbc_counter8.gridy = 2;
		 		 contentPane.add(counter8, gbc_counter8);
		 
		 		
		 		
		 		
		 		
		 		 P8_Button = new JButton("Click");
		 		 GridBagConstraints gbc_P8_Button = new GridBagConstraints();
		 		 gbc_P8_Button.insets = new Insets(0, 0, 5, 5);
		 		 gbc_P8_Button.gridx = 13;
		 		 gbc_P8_Button.gridy = 2;
		 		 contentPane.add(P8_Button, gbc_P8_Button);
		 		 P8_Button.setBackground(Color.green);
		 		 P8_Button.setForeground(Color.white);
		 		 
		 		 counter2 = new JLabel("counter");
		 		 GridBagConstraints gbc_counter2 = new GridBagConstraints();
		 		 gbc_counter2.insets = new Insets(0, 0, 5, 5);
		 		 gbc_counter2.gridx = 14;
		 		 gbc_counter2.gridy = 2;
		 		 contentPane.add(counter2, gbc_counter2);
		 
		 		
		 	
		 		
		 		 P2_Button = new JButton("Click");
		 		 GridBagConstraints gbc_P2_Button = new GridBagConstraints();
		 		 gbc_P2_Button.insets = new Insets(0, 0, 5, 0);
		 		 gbc_P2_Button.gridx = 15;
		 		 gbc_P2_Button.gridy = 2;
		 		 contentPane.add(P2_Button, gbc_P2_Button);
		 		 P2_Button.setBackground(Color.yellow);
		 		 P2_Button.setForeground(Color.black);
		 		 
		 		 counter3 = new JLabel("counter");
		 		 GridBagConstraints gbc_counter3 = new GridBagConstraints();
		 		 gbc_counter3.insets = new Insets(0, 0, 5, 5);
		 		 gbc_counter3.gridx = 14;
		 		 gbc_counter3.gridy = 3;
		 		 contentPane.add(counter3, gbc_counter3);
		 
		 	
		 		
		 		 P3_Button = new JButton("Click");
		 		 GridBagConstraints gbc_P3_Button = new GridBagConstraints();
		 		 gbc_P3_Button.insets = new Insets(0, 0, 5, 0);
		 		 gbc_P3_Button.gridx = 15;
		 		 gbc_P3_Button.gridy = 3;
		 		 contentPane.add(P3_Button, gbc_P3_Button);
		 		 P3_Button.setBackground(Color.pink);
		 		 P3_Button.setForeground(Color.black);
		 		 
		 		 counter4 = new JLabel("counter");
		 		 GridBagConstraints gbc_counter4 = new GridBagConstraints();
		 		 gbc_counter4.insets = new Insets(0, 0, 5, 5);
		 		 gbc_counter4.gridx = 14;
		 		 gbc_counter4.gridy = 4;
		 		 contentPane.add(counter4, gbc_counter4);
		 
		 		
		 		
		 		 P4_Button = new JButton("Click");
		 		 GridBagConstraints gbc_P4_Button = new GridBagConstraints();
		 		 gbc_P4_Button.insets = new Insets(0, 0, 5, 0);
		 		 gbc_P4_Button.gridx = 15;
		 		 gbc_P4_Button.gridy = 4;
		 		 contentPane.add(P4_Button, gbc_P4_Button);
		 		 P4_Button.setBackground(Color.ORANGE);
		 		 P4_Button.setForeground(Color.white);

		
		Done_Button = new JButton("Done");
		GridBagConstraints gbc_Done_Button = new GridBagConstraints();
		gbc_Done_Button.insets = new Insets(0, 0, 5, 5);
		gbc_Done_Button.gridx = 0;
		gbc_Done_Button.gridy = 5;
		contentPane.add(Done_Button, gbc_Done_Button);
				 		 
				 		 counter5 = new JLabel("counter");
				 		 GridBagConstraints gbc_counter5 = new GridBagConstraints();
				 		 gbc_counter5.insets = new Insets(0, 0, 5, 5);
				 		 gbc_counter5.gridx = 14;
				 		 gbc_counter5.gridy = 5;
				 		 contentPane.add(counter5, gbc_counter5);
				 
				 		 
				 		 P5_Button = new JButton("Click");
				 		 GridBagConstraints gbc_P5_Button = new GridBagConstraints();
				 		 gbc_P5_Button.insets = new Insets(0, 0, 5, 0);
				 		 gbc_P5_Button.gridx = 15;
				 		 gbc_P5_Button.gridy = 5;
				 		 contentPane.add(P5_Button, gbc_P5_Button);
				 		 P5_Button.setBackground(Color.gray);
				 		 P5_Button.setForeground(Color.white);
				 		 
				 		 counter6 = new JLabel("counter");
				 		 GridBagConstraints gbc_counter6 = new GridBagConstraints();
				 		 gbc_counter6.insets = new Insets(0, 0, 0, 5);
				 		 gbc_counter6.gridx = 14;
				 		 gbc_counter6.gridy = 6;
				 		 contentPane.add(counter6, gbc_counter6);
				 
				 		 
				 		
				 		
				 		
				 		 P6_Button = new JButton("Click");
				 		 GridBagConstraints gbc_P6_Button = new GridBagConstraints();
				 		 gbc_P6_Button.gridx = 15;
				 		 gbc_P6_Button.gridy = 6;
				 		 contentPane.add(P6_Button, gbc_P6_Button);
				 		 P6_Button.setBackground(Color.MAGENTA);
				 		 P6_Button.setForeground(Color.white);
	}
	public void addP1Listener(ActionListener listen) {
		P1_Button.addActionListener(listen);
	}
	public void addP2Listener(ActionListener listen) {
		P2_Button.addActionListener(listen);
	}
	public void addP3Listener(ActionListener listen) {
		P3_Button.addActionListener(listen);
	}
	public void addP4Listener(ActionListener listen) {
		P4_Button.addActionListener(listen);
	}
	public void addP5Listener(ActionListener listen) {
		P5_Button.addActionListener(listen);
	}
	public void addP6Listener(ActionListener listen) {
		P6_Button.addActionListener(listen);
	}
	public void addP7Listener(ActionListener listen) {
		P7_Button.addActionListener(listen);
	}
	public void addP8Listener(ActionListener listen) {
		P8_Button.addActionListener(listen);
	}
	public void addDoneListener(ActionListener listen) {
		Done_Button.addActionListener(listen);
	}
	public void setCounters(List<Integer> counters) {
		counter1.setText(Integer.toString(counters.get(0)));
		counter2.setText(Integer.toString(counters.get(1)));
		counter3.setText(Integer.toString(counters.get(2)));
		counter4.setText(Integer.toString(counters.get(3)));
		counter5.setText(Integer.toString(counters.get(4)));
		counter6.setText(Integer.toString(counters.get(5)));
		counter7.setText(Integer.toString(counters.get(6)));
		counter8.setText(Integer.toString(counters.get(7)));

	}

	public void displayErrorMessage(String errorMessage) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, errorMessage);	

	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
}
