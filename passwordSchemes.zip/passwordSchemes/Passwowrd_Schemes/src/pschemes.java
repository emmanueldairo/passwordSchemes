	import java.util.ArrayList;
	import java.util.List;

import javax.print.attribute.Size2DSyntax;

	
public class pschemes {

	private boolean validate;
	private List<Integer> Email;
	private List<Integer> Banking;
	private List<Integer> Shopping;
	private int Size;
	private int eTries,sTries,bTries;
	private String userID;

		public pschemes() {
			// TODO Auto-generated constructor stub
			this.setValidate(false);
			setbTries(0);
			seteTries(0);
			setsTries(0);
			Email=new ArrayList<Integer>();
			Banking=new ArrayList<Integer>();
			Shopping=new ArrayList<Integer>();
			Size=8;
			setUserID(null);
			
		}
	   
	     public int generateInt() {
	    	 	int random = 0;
				random= (int) (Math.random()*10);
		    	 	while (random>7) {
						random= (int) (Math.random()*10);
					}  
		    	 	
		    	 	return random;
	     }
	        
	        public  List<Integer> generateEmailPassword() {
	        	
	        	System.out.println("Your Email Password is:");
	        	for (int i = 0; i < Size; i++) {
					Email.add(generateInt());
					System.out.print(Email.get(i));
				}
	          	System.out.println(" ");

	        	return  Email;
			}
	        public List<Integer> getEmail() {
				return Email;
			}
	        public  List<Integer> genetateBankingPassword() {
	        	System.out.println("Your Banking Password is:");
	          	for (int i = 0; i < Size; i++) {
					Banking.add(generateInt());
					System.out.print(Banking.get(i));
				}

	          	System.out.println(" ");
	        	return  Banking;
			}
	        public List<Integer> getBanking() {
				return Banking;
			}
	        public  List<Integer> generateShoppingPassword() {
	        	
	        	System.out.println("Your Shopping Shopping is:");
	          	for (int i = 0; i < Size; i++) {
					Shopping.add(generateInt());
					System.out.print(Shopping.get(i));

				}
	          	System.out.println(" ");

	        	return  Shopping;
			}
	        public List<Integer> getShopping() {
				return Shopping;
			}
	
	        public void passWordChecker(List<Integer> entree, List<Integer> pass) {
	        	int num=0;
	        	setValidate(false);
	        	for (int i = 0; i < pass.size(); i++) {
	        		
	        		if (entree.get(i)==pass.get(i)) {
						num++;
					}		
				}
	        	if (num==Size) {
					setValidate(true);
				}
	        	
			}
	        public boolean passWordChecker(List<Integer> entree, String s) {
	        	int num=0;
	        	boolean correct = false;
	        	switch (s) {
				case "EMAIL":
					for (int i = 0; i < Email.size(); i++) {
		        		if (entree.get(i)==Email.get(i)) {
							num++;
						}			
					}
					if (num==Size) {
						correct=true;
					}else {
						correct=false;	
					}
					break;
				case "BANKING":
					for (int i = 0; i < Banking.size(); i++) {
		        		if (entree.get(i)==Banking.get(i)) {
							num++;
						}			
					}
					if (num==Size) {
						correct=true;
					}else {
						correct=false;
					}
					break;
				case "SHOPPING":
					for (int i = 0; i < Email.size(); i++) {
		        		if (entree.get(i)==Email.get(i)) {
							num++;
						}			
					}
					if (num==Size) {
						correct=true;
					}else {
						correct=false;
					}
					break;
				default:
					break;
				}
	        	
	        	return correct;
			}
	        public boolean getValidate() {
				return this.validate;
			}
	        public void setValidate(boolean b) {
				// TODO Auto-generated method stub
				this.validate=b;
			}

		
			public int geteTries() {
				return eTries;
			}

			public void seteTries(int eTries) {
				this.eTries = eTries;
			}

			public int getsTries() {
				return sTries;
			}

			public void setsTries(int sTries) {
				this.sTries = sTries;
			}

			public int getbTries() {
				return bTries;
			}

			public void setbTries(int bTries) {
				this.bTries = bTries;
			}

			public String getUserID() {
				return userID;
			}

			public void setUserID(String userID) {
				this.userID = userID;
			}	
			
}
