import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JCheckBox;

public class TestGetPasswordGui extends JFrame {

	private JPanel contentPane;
	private String Ptype;
	private JButton P1_Button;
	private JButton P2_Button;
	private JButton P3_Button;
	private JButton P4_Button;
	private JButton P5_Button;
	private JButton P6_Button;
	private JButton P7_Button;
	private JButton P8_Button;
	private JButton ConfirmButton;
	private JCheckBox VisibilityCheckBox;
	private JLabel lblCheckTheBox;
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JLabel lbl4;
	private JLabel lbl5;
	private JLabel lbl6;
	private JLabel lbl7;
	private JLabel lbl8;
	private JButton acceptButton;
	private JLabel counter1;
	private JLabel counter2;
	private JLabel counter3;
	private JLabel counter4;
	private JLabel counter5;
	private JLabel counter6;
	private JLabel counter7;
	private JLabel counter8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestGetPasswordGui frame = new TestGetPasswordGui("Email");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TestGetPasswordGui(String s) {
		setPtype(s);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1081, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 63, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Click Buttons to match numbers to test Password!\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 8;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		 lbl7 = new JLabel();
		 lbl7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl7 = new GridBagConstraints();
		gbc_lbl7.insets = new Insets(0, 0, 5, 5);
		gbc_lbl7.gridx = 12;
		gbc_lbl7.gridy = 1;
		contentPane.add(lbl7, gbc_lbl7);
		 
		  P7_Button = new JButton("Click");
		  GridBagConstraints gbc_P7_Button = new GridBagConstraints();
		  gbc_P7_Button.insets = new Insets(0, 0, 5, 5);
		  gbc_P7_Button.gridx = 13;
		  gbc_P7_Button.gridy = 1;
		  contentPane.add(P7_Button, gbc_P7_Button);
		  P7_Button.setBackground(Color.BLACK);
		  P7_Button.setForeground(Color.white);
		 
		 counter7 = new JLabel("counter");
		 GridBagConstraints gbc_counter7 = new GridBagConstraints();
		 gbc_counter7.insets = new Insets(0, 0, 5, 5);
		 gbc_counter7.gridx = 14;
		 gbc_counter7.gridy = 1;
		 contentPane.add(counter7, gbc_counter7);

		
		 lbl1 = new JLabel();
		 lbl1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl1 = new GridBagConstraints();
		gbc_lbl1.insets = new Insets(0, 0, 5, 5);
		gbc_lbl1.gridx = 15;
		gbc_lbl1.gridy = 1;
		contentPane.add(lbl1, gbc_lbl1);
		
		 P1_Button = new JButton("Click");
		GridBagConstraints gbc_P1_Button = new GridBagConstraints();
		gbc_P1_Button.insets = new Insets(0, 0, 5, 5);
		gbc_P1_Button.gridx = 16;
		gbc_P1_Button.gridy = 1;
		contentPane.add(P1_Button, gbc_P1_Button);
		P1_Button.setBackground(Color.blue);
		P1_Button.setForeground(Color.white);
		 
		 counter1 = new JLabel("counter");
		 GridBagConstraints gbc_counter1 = new GridBagConstraints();
		 gbc_counter1.insets = new Insets(0, 0, 5, 0);
		 gbc_counter1.gridx = 17;
		 gbc_counter1.gridy = 1;
		 contentPane.add(counter1, gbc_counter1);

		
		
		 lbl8 = new JLabel();
		 lbl8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl8 = new GridBagConstraints();
		gbc_lbl8.insets = new Insets(0, 0, 5, 5);
		gbc_lbl8.gridx = 12;
		gbc_lbl8.gridy = 2;
		contentPane.add(lbl8, gbc_lbl8);
		 
		  P8_Button = new JButton("Click");
		  GridBagConstraints gbc_P8_Button = new GridBagConstraints();
		  gbc_P8_Button.insets = new Insets(0, 0, 5, 5);
		  gbc_P8_Button.gridx = 13;
		  gbc_P8_Button.gridy = 2;
		  contentPane.add(P8_Button, gbc_P8_Button);
		  P8_Button.setBackground(Color.green);
		  P8_Button.setForeground(Color.white);
		 
		 counter8 = new JLabel("counter");
		 GridBagConstraints gbc_counter8 = new GridBagConstraints();
		 gbc_counter8.insets = new Insets(0, 0, 5, 5);
		 gbc_counter8.gridx = 14;
		 gbc_counter8.gridy = 2;
		 contentPane.add(counter8, gbc_counter8);

		
		 lbl2 = new JLabel();
		 lbl2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl2 = new GridBagConstraints();
		gbc_lbl2.insets = new Insets(0, 0, 5, 5);
		gbc_lbl2.gridx = 15;
		gbc_lbl2.gridy = 2;
		contentPane.add(lbl2, gbc_lbl2);
		
		 P2_Button = new JButton("Click");
		GridBagConstraints gbc_P2_Button = new GridBagConstraints();
		gbc_P2_Button.insets = new Insets(0, 0, 5, 5);
		gbc_P2_Button.gridx = 16;
		gbc_P2_Button.gridy = 2;
		contentPane.add(P2_Button, gbc_P2_Button);
		P2_Button.setBackground(Color.yellow);
		P2_Button.setForeground(Color.black);
		 
		 counter2 = new JLabel("counter");
		 GridBagConstraints gbc_counter2 = new GridBagConstraints();
		 gbc_counter2.insets = new Insets(0, 0, 5, 0);
		 gbc_counter2.gridx = 17;
		 gbc_counter2.gridy = 2;
		 contentPane.add(counter2, gbc_counter2);

		 lbl3 = new JLabel();
		 lbl3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl3 = new GridBagConstraints();
		gbc_lbl3.insets = new Insets(0, 0, 5, 5);
		gbc_lbl3.gridx = 15;
		gbc_lbl3.gridy = 3;
		contentPane.add(lbl3, gbc_lbl3);
		
		 P3_Button = new JButton("Click");
		GridBagConstraints gbc_P3_Button = new GridBagConstraints();
		gbc_P3_Button.insets = new Insets(0, 0, 5, 5);
		gbc_P3_Button.gridx = 16;
		gbc_P3_Button.gridy = 3;
		contentPane.add(P3_Button, gbc_P3_Button);
		P3_Button.setBackground(Color.pink);
		P3_Button.setForeground(Color.black);
		
		counter3 = new JLabel("counter");
		GridBagConstraints gbc_counter3 = new GridBagConstraints();
		gbc_counter3.insets = new Insets(0, 0, 5, 0);
		gbc_counter3.gridx = 17;
		gbc_counter3.gridy = 3;
		contentPane.add(counter3, gbc_counter3);

		lblCheckTheBox = new JLabel("Check the box to make your real password hidden or shown.");
		lblCheckTheBox.setFont(new Font("Tahoma", Font.BOLD, 20));
		GridBagConstraints gbc_lblCheckTheBox = new GridBagConstraints();
		gbc_lblCheckTheBox.gridwidth = 8;
		gbc_lblCheckTheBox.insets = new Insets(0, 0, 5, 5);
		gbc_lblCheckTheBox.gridx = 2;
		gbc_lblCheckTheBox.gridy = 4;
		contentPane.add(lblCheckTheBox, gbc_lblCheckTheBox);
		
		VisibilityCheckBox = new JCheckBox();
		VisibilityCheckBox.setSelected(true);
		GridBagConstraints gbc_VisibilityCheckBox = new GridBagConstraints();
		gbc_VisibilityCheckBox.insets = new Insets(0, 0, 5, 5);
		gbc_VisibilityCheckBox.gridx = 10;
		gbc_VisibilityCheckBox.gridy = 4;
		contentPane.add(VisibilityCheckBox, gbc_VisibilityCheckBox);
		
		 lbl4 = new JLabel();
		 lbl4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl4 = new GridBagConstraints();
		gbc_lbl4.insets = new Insets(0, 0, 5, 5);
		gbc_lbl4.gridx = 15;
		gbc_lbl4.gridy = 4;
		contentPane.add(lbl4, gbc_lbl4);
		
		 P4_Button = new JButton("Click");
		GridBagConstraints gbc_P4_Button = new GridBagConstraints();
		gbc_P4_Button.insets = new Insets(0, 0, 5, 5);
		gbc_P4_Button.gridx = 16;
		gbc_P4_Button.gridy = 4;
		contentPane.add(P4_Button, gbc_P4_Button);
		P4_Button.setBackground(Color.ORANGE);
		P4_Button.setForeground(Color.white);
		 
		 counter4 = new JLabel("counter");
		 GridBagConstraints gbc_counter4 = new GridBagConstraints();
		 gbc_counter4.insets = new Insets(0, 0, 5, 0);
		 gbc_counter4.gridx = 17;
		 gbc_counter4.gridy = 4;
		 contentPane.add(counter4, gbc_counter4);

		 lbl5 = new JLabel();
		 lbl5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl5 = new GridBagConstraints();
		gbc_lbl5.insets = new Insets(0, 0, 5, 5);
		gbc_lbl5.gridx = 15;
		gbc_lbl5.gridy = 5;
		contentPane.add(lbl5, gbc_lbl5);
		
		 P5_Button = new JButton("Click");
		GridBagConstraints gbc_P5_Button = new GridBagConstraints();
		gbc_P5_Button.insets = new Insets(0, 0, 5, 5);
		gbc_P5_Button.gridx = 16;
		gbc_P5_Button.gridy = 5;
		contentPane.add(P5_Button, gbc_P5_Button);
		P5_Button.setBackground(Color.gray);
		P5_Button.setForeground(Color.white);
		 
		 counter5 = new JLabel("counter");
		 GridBagConstraints gbc_counter5 = new GridBagConstraints();
		 gbc_counter5.insets = new Insets(0, 0, 5, 0);
		 gbc_counter5.gridx = 17;
		 gbc_counter5.gridy = 5;
		 contentPane.add(counter5, gbc_counter5);

		 acceptButton = new JButton("Accept");
		 GridBagConstraints gbc_acceptButton = new GridBagConstraints();
		 gbc_acceptButton.insets = new Insets(0, 0, 0, 5);
		 gbc_acceptButton.gridx = 6;
		 gbc_acceptButton.gridy = 6;
		 contentPane.add(acceptButton, gbc_acceptButton);
		
		 ConfirmButton = new JButton("Confirm");
		GridBagConstraints gbc_ConfirmButton = new GridBagConstraints();
		gbc_ConfirmButton.insets = new Insets(0, 0, 0, 5);
		gbc_ConfirmButton.gridx = 9;
		gbc_ConfirmButton.gridy = 6;
		contentPane.add(ConfirmButton, gbc_ConfirmButton);
		
		 lbl6 = new JLabel();
		 lbl6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_lbl6 = new GridBagConstraints();
		gbc_lbl6.insets = new Insets(0, 0, 0, 5);
		gbc_lbl6.gridx = 15;
		gbc_lbl6.gridy = 6;
		contentPane.add(lbl6, gbc_lbl6);
		
		 P6_Button = new JButton("Click");
		GridBagConstraints gbc_P6_Button = new GridBagConstraints();
		gbc_P6_Button.insets = new Insets(0, 0, 0, 5);
		gbc_P6_Button.gridx = 16;
		gbc_P6_Button.gridy = 6;
		contentPane.add(P6_Button, gbc_P6_Button);
		P6_Button.setBackground(Color.MAGENTA);
		P6_Button.setForeground(Color.white);
		
		counter6 = new JLabel("counter");
		GridBagConstraints gbc_counter6 = new GridBagConstraints();
		gbc_counter6.gridx = 17;
		gbc_counter6.gridy = 6;
		contentPane.add(counter6, gbc_counter6);

	}

	public void setPassword(List<Integer> alist) {
		lbl1.setText(Integer.toString(alist.get(0)));
		lbl2.setText(Integer.toString(alist.get(1)));
		lbl3.setText(Integer.toString(alist.get(2)));
		lbl4.setText(Integer.toString(alist.get(3)));
		lbl5.setText(Integer.toString(alist.get(4)));
		lbl6.setText(Integer.toString(alist.get(5)));
		lbl7.setText(Integer.toString(alist.get(6)));
		lbl8.setText(Integer.toString(alist.get(7)));
		

	}
	public List<JLabel> getPassword() {
		List<JLabel> Password= new ArrayList<JLabel>();
		
		Password.add(lbl1);
		Password.add(lbl2);
		Password.add(lbl3);
		Password.add(lbl4);
		Password.add(lbl5);
		Password.add(lbl6);
		Password.add(lbl7);
		Password.add(lbl8);

	
		return Password;
	}
	public void setCounters(List<Integer> counters) {
		counter1.setText(Integer.toString(counters.get(0)));
		counter2.setText(Integer.toString(counters.get(1)));
		counter3.setText(Integer.toString(counters.get(2)));
		counter4.setText(Integer.toString(counters.get(3)));
		counter5.setText(Integer.toString(counters.get(4)));
		counter6.setText(Integer.toString(counters.get(5)));
		counter7.setText(Integer.toString(counters.get(6)));
		counter8.setText(Integer.toString(counters.get(7)));

	}
	public void addVisibleListener(ActionListener listen) {
		VisibilityCheckBox.addActionListener(listen);
	}
	public void addP1Listener(ActionListener listen) {
		P1_Button.addActionListener(listen);
	}
	public void addP2Listener(ActionListener listen) {
		P2_Button.addActionListener(listen);
	}
	public void addP3Listener(ActionListener listen) {
		P3_Button.addActionListener(listen);
	}
	public void addP4Listener(ActionListener listen) {
		P4_Button.addActionListener(listen);
	}
	public void addP5Listener(ActionListener listen) {
		P5_Button.addActionListener(listen);
	}
	public void addP6Listener(ActionListener listen) {
		P6_Button.addActionListener(listen);
	}
	public void addP7Listener(ActionListener listen) {
		P7_Button.addActionListener(listen);
	}
	public void addP8Listener(ActionListener listen) {
		P8_Button.addActionListener(listen);
	}
	public void confirmListener(ActionListener listen) {
		ConfirmButton.addActionListener(listen);
	}
	public void AcceptListener(ActionListener listen) {
		acceptButton.addActionListener(listen);
	}
	public String getPtype() {
		return Ptype;
	}
	public void displayErrorMessage(String errorMessage){
		JOptionPane.showMessageDialog(this, errorMessage);	
	}
	public void setPtype(String ptype) {
		Ptype = ptype;
	}

	public boolean checkPasswordVisibility() {
		// TODO Auto-generated method stub
		return VisibilityCheckBox.isSelected();
	}

	public List<Integer> getIntPassword() {
		// TODO Auto-generated method stub
		
		List<Integer> Password= new ArrayList<Integer>();
		
		Password.add(Integer.parseInt(lbl1.getText()));
		Password.add(Integer.parseInt(lbl2.getText()));
		Password.add(Integer.parseInt(lbl3.getText()));
		Password.add(Integer.parseInt(lbl4.getText()));
		Password.add(Integer.parseInt(lbl5.getText()));
		Password.add(Integer.parseInt(lbl6.getText()));
		Password.add(Integer.parseInt(lbl7.getText()));
		Password.add(Integer.parseInt(lbl8.getText()));


	
		return Password;	
	}

}
